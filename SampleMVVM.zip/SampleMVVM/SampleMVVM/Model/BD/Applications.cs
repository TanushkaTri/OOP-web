﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.Model.BD
{
    public class Applications
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int TarifId { get; set; }
        public int TeacherId { get; set; }
    }
}
