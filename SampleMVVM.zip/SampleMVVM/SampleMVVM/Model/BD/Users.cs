﻿using SampleMVVM.Managers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.Model.BD
{
    public class Users
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; } = "-";
        public string LastName { get; set; } = "-";
        public string Surname { get; set; } = "-";
        public UserList UserList { get; set; }
        public string PhotoPath { get; set; } = @"C:\Users\triko\Desktop\Курсовой ООП\SampleMVVM\Resources\User.png";
    }
}
