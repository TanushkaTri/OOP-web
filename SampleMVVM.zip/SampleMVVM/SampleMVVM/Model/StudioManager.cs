﻿using SampleMVVM.DataBase.UnitOfWorks;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Numerics;
using WMPLib;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SampleMVVM.Managers
{
    public class StudioManager
    {
        public static StudioManager Instance { get; set; }

        public UnitOfWork unitOfWork = new UnitOfWork();

        static StudioManager()
        {
            Instance = new StudioManager();
        }

      

    }
}

