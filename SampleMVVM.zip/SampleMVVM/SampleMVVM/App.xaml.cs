﻿using System.Windows;


namespace SampleMVVM
{
    public partial class App : Application
    {
    }
}
