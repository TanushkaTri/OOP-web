﻿
using Microsoft.Win32;
using Newtonsoft.Json.Serialization;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;

using SampleMVVM.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WMPLib;

namespace SampleMVVM.ViewModels
{
    public class FormToAddTarifViewModel : ViewModelBase
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Duration { get; set; }
        public int Cost { get; set; }

        public TarifsAndTeachersViewModel s;

        #region Errors
        private string errorName = string.Empty;
        private int errorCost = 0;
        private int errorDuration = 0;
        private string errorTitle = string.Empty;
        private string errorNameText = string.Empty;
        private string errorDurationText = string.Empty;
        private string errorCostText = string.Empty;
        private string errorTitleText = string.Empty;
        public string ErrorName
        {
            get => errorName;
            set
            {
                errorName = value;
                OnPropertyChanged(nameof(ErrorName));
            }
        }
        public int ErrorDuration
        {
            get => errorDuration;
            set
            {
                errorDuration = value;
                OnPropertyChanged(nameof(ErrorDuration));
            }
        }
        public int ErrorCost
        {
            get => errorCost;
            set
            {
                errorCost = value;
                OnPropertyChanged(nameof(ErrorCost));
            }
        }
        public string ErrorTitle
        {
            get => errorTitle;
            set
            {
                errorTitle = value;
                OnPropertyChanged(nameof(ErrorTitle));
            }
        }

        public string ErrorNameText
        {
            get => errorNameText;
            set
            {
                errorNameText = value;
                OnPropertyChanged(nameof(ErrorNameText));
            }
        }

        public string ErrorDurationText
        {
            get => errorDurationText;
            set
            {
                errorDurationText = value;
                OnPropertyChanged(nameof(ErrorDurationText));
            }
        }

        public string ErrorCostText
        {
            get => errorCostText;
            set
            {
                errorCostText = value;
                OnPropertyChanged(nameof(ErrorCostText));
            }
        }

        public string ErrorTitleText
        {
            get => errorTitleText;
            set
            {
                errorTitleText = value;
                OnPropertyChanged(nameof(ErrorTitleText));
            }
        }
        #endregion
        public string Image { get; set; }

        private FormToAddNewTarif windows;
        private DelegateCommand createItem;
        public FormToAddTarifViewModel(FormToAddNewTarif windows, TarifsAndTeachersViewModel vm)
        {
            this.windows = windows;
            s = vm;
        }
        public ICommand CreateItem
        {
            get
            {
                if (createItem == null)
                {
                    createItem = new DelegateCommand(AddTarif);
                }
                return createItem;
            }
        }
        private void AddTarif()
        {
            // Сбросить все ошибки
            ErrorName = string.Empty;
            ErrorDuration = 0;
            ErrorCost = 0;
            ErrorTitle = string.Empty;
            ErrorNameText = string.Empty;
            ErrorDurationText = string.Empty;
            ErrorCostText = string.Empty;
            ErrorTitleText = string.Empty;

            if (Image == null)
            {
                ErrorTitle = Application.Current.FindResource("ErrorImage").ToString();
                ErrorTitleText = "Пожалуйста, выберите изображение для тарифа.";
                return;
            }
            else if (string.IsNullOrWhiteSpace(Name))
            {
                ErrorName = Application.Current.FindResource("ErrorName").ToString();
                ErrorNameText = "Название тарифа не может быть пустым.";
                return;
            }
            else if (string.IsNullOrWhiteSpace(Description))
            {
                ErrorTitle = Application.Current.FindResource("ErrorTitle").ToString();
                ErrorTitleText = "Описание тарифа не может быть пустым.";
                return;
            }
            else if (Duration <= 0)
            {
                ErrorDuration = 1;
                ErrorDurationText = "Продолжительность тарифа должна быть положительным числом.";
                return;
            }
            else if (Cost <= 0)
            {
                ErrorCost = 1;
                ErrorCostText = "Стоимость тарифа должна быть положительным числом.";
                return;
            }
            
            Tarif tarif = new Tarif();
            tarif.Name = Name;
            tarif.Title = Description;
            tarif.ImagePath = Image;
            tarif.Duration = Duration;
            tarif.Cost = Cost;

            StudioManager.Instance.unitOfWork.TarifsRepositories.Create(tarif);
            StudioManager.Instance.unitOfWork.Save();

            MessageBox.Show(Application.Current.FindResource("gut").ToString());
            s.RefreshTarifs();
            CloseWindow();
        }

        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (windows != null)
            {
                windows.Close();
            }
        }
        #region Добавить изображение
        private DelegateCommand loadImageCommand;
        public ICommand LoadImageCommand
        {
            get
            {
                if (loadImageCommand == null)
                {
                    loadImageCommand = new DelegateCommand(LoadImage);
                }
                return loadImageCommand;
            }
        }

        private void LoadImage()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
               Image = openFileDialog.FileName;
            }
        }
        #endregion
    }
}
