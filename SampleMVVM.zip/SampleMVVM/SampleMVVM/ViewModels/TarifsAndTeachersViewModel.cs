﻿using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class TarifsAndTeachersViewModel : ViewModelBase
    {

        private ObservableCollection<Tarif> tarifs;
        private ObservableCollection<Teacher> teachers;
        public ObservableCollection<Tarif> Tarifs
        {
            get { return tarifs; }
            set { tarifs = value; OnPropertyChanged(nameof(Tarifs)); }
        }
        public ObservableCollection<Teacher> Teachers
        {
            get { return teachers; }
            set { teachers = value; OnPropertyChanged(nameof(Teachers)); }
        }
        public void RefreshTeachers()
        {
            Teachers = new ObservableCollection<Teacher>(db.GetTeacherList());
        }
        public void RefreshTarifs()
        {
            Tarifs = new ObservableCollection<Tarif>(db.GetTarifsList());
        }

        public TarifsAndTeachersViewModel()
        {
            RefreshTarifs();
            RefreshTeachers();

        }


        private bool isAdmin;
        private bool isUser;
        public bool CheckAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; OnPropertyChanged(nameof(CheckAdmin)); }
        }
        public bool CheckUser
        {
            get { return isUser; }
            set { isUser = value; OnPropertyChanged(nameof(CheckUser)); }
        }
        public void SetUserRoles(bool admin, bool user)
        {
            isAdmin = admin;
            isUser = user;
        }
        #region Выбраный тариф и преподаватель
        private Tarif selectedTarif;
        public Tarif SelectedTarif
        {
            get { return selectedTarif; }
            set
            {
                if (selectedTarif != value)
                {
                    selectedTarif = value;
                    OnPropertyChanged(nameof(SelectedTarif));
                }
            }
        }
        private Teacher selectedTeacher;
        public Teacher SelectedTeacher
        {
            get { return selectedTeacher; }
            set
            {
                if (selectedTeacher != value)
                {
                    selectedTeacher = value;
                    OnPropertyChanged(nameof(SelectedTeacher));
                }
            }
        }
        private Tarif GetSelectedTarif()
        {
            if (Tarifs == null || Tarifs.Count == 0)
            {
                return null;
            }
            return SelectedTarif;
        }
        private Teacher GetSelectedTeacher()
        {
            if (Teachers == null || Teachers.Count == 0)
            {
                return null;
            }
            return SelectedTeacher;
        }
        #endregion
        #region Удаление изменение тарифа
        private DelegateCommand refreshCommand;
        public ICommand RefreshCommand
        {
            get
            {
                if (refreshCommand == null)
                {
                    refreshCommand = new DelegateCommand(EditTarif);
                }
                return refreshCommand;
            }
        }
        private void EditTarif()
        {
            Tarif selectedTarif = GetSelectedTarif();
            var editView = new EditTarifView();
            TarifEditionViewModel editViewModel = new TarifEditionViewModel(selectedTarif, editView);
            editView.DataContext = editViewModel;
            editView.ShowDialog();
            RefreshTarifs();
        }
      
        private DelegateCommand deleteCommand;
        public ICommand DeleteComand
        {
            get
            {
                if (deleteCommand == null)
                {
                    deleteCommand = new DelegateCommand(DeleteTarif);
                }
                return deleteCommand;
            }
        }
        private void DeleteTarif()
        {
            Tarif currentTarif = GetSelectedTarif();
            StudioManager.Instance.unitOfWork.TarifsRepositories.DeleteByName(currentTarif);
            RefreshTarifs();
        }
        #endregion
        #region Удаление изменение преподавателя
        private DelegateCommand deleteTeacherCommand;
        public ICommand DeleteTeacherComand
        {
            get
            {
                if (deleteTeacherCommand == null)
                {
                    deleteTeacherCommand = new DelegateCommand(DeleteTeacher);
                }
                return deleteTeacherCommand;
            }
        }
        private void DeleteTeacher()
        {
            Teacher currentTeacher = GetSelectedTeacher();
            StudioManager.Instance.unitOfWork.TeacherRepositories.DeleteByName(currentTeacher);
            RefreshTeachers();
        }
        private DelegateCommand editTeacher;
        public ICommand EditTeacher
        {
            get
            {
                if (editTeacher == null)
                {
                    editTeacher = new DelegateCommand(EditCurrentTeacher);
                }
                return editTeacher;
            }
        }
        public void EditCurrentTeacher()
        {
            Teacher selectedTeacher = GetSelectedTeacher();
            var editView = new TeacherEditionView();
            TeacherEditionViewModel editViewModel = new TeacherEditionViewModel(editView, selectedTeacher);
            editView.DataContext = editViewModel;
            editView.ShowDialog();
            RefreshTeachers();
        }
        #endregion

        private DelegateCommand openTarifCommand;
        public ICommand OpenTarifCommand
        {
            get
            {
                if (openTarifCommand == null)
                {
                    openTarifCommand = new DelegateCommand(OpenTarif);
                }
                return openTarifCommand;
            }
        }
        private void OpenTarif()
        {
            Tarif currentTarif = GetSelectedTarif();
            var tarif = new CurrentTarifView();
            CurrentTarifViewModel ViewModel = new CurrentTarifViewModel(tarif, currentTarif);
            tarif.DataContext = ViewModel;
            tarif.ShowDialog();
        }
        private DelegateCommand openTeacherCommand;
        public ICommand OpenTeacherCommand
        {
            get
            {
                if (openTeacherCommand == null)
                {
                    openTeacherCommand = new DelegateCommand(OpenTeacher);
                }
                return openTeacherCommand;
            }
        }
        private void OpenTeacher()
        {
            Teacher currentTeacher = GetSelectedTeacher();
            var teach = new CurrentTeacher();
            CurrentTeacherViewModel ViewModel = new CurrentTeacherViewModel(teach, currentTeacher);
            teach.DataContext = ViewModel;
            teach.ShowDialog();
        }
        private DelegateCommand addApplicationCommand;
        public ICommand AddApplicationCommand
        {
            get
            {
                if (addApplicationCommand == null)
                {
                    addApplicationCommand = new DelegateCommand(AddApplication);
                }
                return addApplicationCommand;
            }
        }
        private void AddApplication()
        {

            if(SelectedTarif == null)
            {
                MessageBox.Show(Application.Current.FindResource("WrongTarif").ToString());
                return;
            }
            if(SelectedTeacher == null)
            {
                MessageBox.Show(Application.Current.FindResource("WrongTeacher").ToString());
                return;
            }
            if(SelectedTeacher == null && selectedTarif == null)
            {
                MessageBox.Show(Application.Current.FindResource("AllWrong").ToString());
                return;
            }

            Users user = CurrentUser;
            Teacher teacher = selectedTeacher;
            Tarif tarif = selectedTarif;
            Applications application = new Applications();
            application.TarifId = tarif.Id;
            application.TeacherId = teacher.Id;

            if (user == null)
            {
                MessageBox.Show("Администраторы не могут добавлять в корзину, только работа с бд!Так понравились наши тарифы? Регистрируйся и записывайся ;)!");
                return;
            }
            if (user.UserName == "admin")
            {
                MessageBox.Show("Администраторы не могут создавать заявления!");
                return;
            }
            application.UserId = user.Id;
            StudioManager.Instance.unitOfWork.ApplicationRepository.Create(application);
            StudioManager.Instance.unitOfWork.Save();
            RefreshAllApplications();
            MessageBox.Show(Application.Current.FindResource("gut1").ToString());
            ShowPage(new ApplicationsView());
        }
        private string searchText;
        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                OnPropertyChanged(nameof(SearchText));
                FilterTeachersAndTarifs();
            }
        }
        private void FilterTeachersAndTarifs()
        {
            if (string.IsNullOrEmpty(SearchText))
            {
                RefreshTeachers();
                RefreshTarifs();
            }
            else
            {
                Teachers = new ObservableCollection<Teacher>(Teachers.Where(t => t.Name.ToLower().Contains(SearchText.ToLower())));
                Tarifs = new ObservableCollection<Tarif>(Tarifs.Where(t => t.Name.ToLower().Contains(SearchText.ToLower())));
            }
        }

        #region Команды сортировки для тарифов

        private ICommand sortByNameTarifCommand;
        public ICommand SortByNameTarifCommand
        {
            get
            {
                return sortByNameTarifCommand ?? (sortByNameTarifCommand = new DelegateCommand(SortByNameTarif));
            }
        }

        private void SortByNameTarif()
        {
            Tarifs = new ObservableCollection<Tarif>(Tarifs.OrderBy(t => t.Name));
        }

        private ICommand sortByDescTarifCommand;
        public ICommand SortByDescTarifCommand
        {
            get
            {
                return sortByDescTarifCommand ?? (sortByDescTarifCommand = new DelegateCommand(SortByDescTarif));
            }
        }

        private void SortByDescTarif()
        {
            Tarifs = new ObservableCollection<Tarif>(Tarifs.OrderBy(t => t.Title));
        }

        private ICommand sortByDurationTarifCommand;
        public ICommand SortByDurationTarifCommand
        {
            get
            {
                return sortByDurationTarifCommand ?? (sortByDurationTarifCommand = new DelegateCommand(SortByDurationTarif));
            }
        }

        private void SortByDurationTarif()
        {
            Tarifs = new ObservableCollection<Tarif>(Tarifs.OrderBy(t => t.Duration));
        }

        private ICommand sortByCostTarifCommand;
        public ICommand SortByCostTarifCommand
        {
            get
            {
                return sortByCostTarifCommand ?? (sortByCostTarifCommand = new DelegateCommand(SortByCostTarif));
            }
        }

        private void SortByCostTarif()
        {
            Tarifs = new ObservableCollection<Tarif>(Tarifs.OrderBy(t => t.Cost));
        }

        #endregion

        #region Команды сортировки для преподавателей

        private ICommand sortByNameTeacherCommand;
        public ICommand SortByNameTeacherCommand
        {
            get
            {
                return sortByNameTeacherCommand ?? (sortByNameTeacherCommand = new DelegateCommand(SortByNameTeacher));
            }
        }

        private void SortByNameTeacher()
        {
            Teachers = new ObservableCollection<Teacher>(Teachers.OrderBy(t => t.Name));
        }

        private ICommand sortByDescTeacherCommand;
        public ICommand SortByDescTeacherCommand
        {
            get
            {
                return sortByDescTeacherCommand ?? (sortByDescTeacherCommand = new DelegateCommand(SortByDescTeacher));
            }
        }

        private void SortByDescTeacher()
        {
            Teachers = new ObservableCollection<Teacher>(Teachers.OrderBy(t => t.Description));
        }

        private ICommand sortByExptTeacherCommand;
        public ICommand SortByExptTeacherCommand
        {
            get
            {
                return sortByExptTeacherCommand ?? (sortByExptTeacherCommand = new DelegateCommand(SortByExptTeacher));
            }
        }

        private void SortByExptTeacher()
        {
            Teachers = new ObservableCollection<Teacher>(Teachers.OrderBy(t => t.Experiance));
        }

        private ICommand sortByPositionTeacherCommand;
        public ICommand SortByPositionTeacherCommand
        {
            get
            {
                return sortByPositionTeacherCommand ?? (sortByPositionTeacherCommand = new DelegateCommand(SortByPositionTeacher));
            }
        }

        private void SortByPositionTeacher()
        {
            Teachers = new ObservableCollection<Teacher>(Teachers.OrderBy(t => t.Position));
        }

        #endregion

    }
}
