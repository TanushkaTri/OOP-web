﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Views;
using SampleMVVM.DataBase;
using System.Diagnostics;
using System.Windows.Media;
using NAudio.Wave;
using System.Threading.Tasks;
using System.ComponentModel;
using GalaSoft.MvvmLight.Command;
using System.Windows.Threading;
using WMPLib;
using System.Runtime.CompilerServices;
using System.Windows.Controls.Primitives;
using TarifsAndTeachers = SampleMVVM.Views.TarifsAndTeachers;
using SampleMVVM.Model.BD;
using System.Collections.ObjectModel;

namespace SampleMVVM.ViewModels
{
    class MainViewModel  : ViewModelBase
    {
        private static bool chek = true;
        private static bool chekLNG = true;
        private static MainViewModel thisMein;

        private FormToAddNewTarif _addTarifViewModel;
        private ProfileViewModel _profileViewModel;
        private MainPageViewModel _mainPageViewModel;
        private ApplicationsViewModel _applicationsViewModel;

        public TarifsAndTeachersViewModel _tarifsAndTeachersViewModel;
        
        private bool isAdmin;
        private bool isUser;
        private bool checkClose = false;
        public MainViewModel()
        {
            _addTarifViewModel = new FormToAddNewTarif();
            _profileViewModel = new ProfileViewModel();
            _mainPageViewModel = new MainPageViewModel();
            _tarifsAndTeachersViewModel = new TarifsAndTeachersViewModel();
            _applicationsViewModel = new ApplicationsViewModel();
            isAdmin = IsAdmin;
            isUser = IsUser;
            thisMein = this;
        }

        public static MainViewModel ThisMein
        {
            get { return thisMein; }
        }
        public Frame CurrentFrame
        {
            set
            {
                MainView.MainFrame.Content = value;
                OnPropertyChanged(nameof(CurrentFrame));
            }
        }
        public bool CheckAdmin
        {
            get
            {
                return isAdmin;
            }
        }
        public bool CheckUser
        {
            get
            {
                return isUser;
            }
        }
        #region Смена языка

        private DelegateCommand testSmena;
        public ICommand LangSmena
        {
            get
            {
                if (testSmena == null)
                {
                    testSmena = new DelegateCommand(LoadResourcesForEnglishSmena);
                }
                return testSmena;
            }
        }
        private void LoadResourcesForEnglishSmena()
        {

            foreach (var dict in Application.Current.Resources.MergedDictionaries)
            {
                if (dict.Source != null && dict.Source.OriginalString.Contains("lang"))
                {
                    Application.Current.Resources.MergedDictionaries.Remove(dict);
                    break;
                }
            }
            var appResources = Application.Current.Resources;
            if (chekLNG)
            {

                Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary()
                {
                    Source = new Uri(
                        String.Format($"/ResiurceDictionary/lang-RU.xaml"),
                        UriKind.Relative)
                });
                Image = @"C:\Users\triko\Desktop\Курсовой ООП\SampleMVVM\SampleMVVM\res\ru.png";
                chekLNG = false;
            }
            else
            {
                Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary()
                {
                    Source = new Uri(
                        String.Format($"/ResiurceDictionary/lang-ENG.xaml"),
                        UriKind.Relative)
                });
                Image = @"C:\Users\triko\Desktop\Курсовой ООП\SampleMVVM\SampleMVVM\res\us.png";
                chekLNG = true;
            }
        }
        private string image = @"C:\Users\triko\Desktop\Курсовой ООП\SampleMVVM\SampleMVVM\res\ru.png";
        public string Image
        {
            get
            {
                return image;
            }
            set
            {
                image = value;
                OnPropertyChanged(nameof(image));
            }
        }

        #endregion
        #region Смена стилей
        private DelegateCommand giveItemCommand;
        public ICommand SetTheme
        {
            get
            {
                if (giveItemCommand == null)
                {
                    giveItemCommand = new DelegateCommand(setTheme);
                }
                return giveItemCommand;
            }
        }
        private static void setTheme()
        {
            if (chek)
            {
                Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary()
                {
                    Source = new Uri( String.Format($"/ResiurceDictionary/light.xaml"), UriKind.Relative)
                }
                );
                chek = false;
                return;
            }
            else
            {
                Application.Current.Resources.MergedDictionaries.Add(new ResourceDictionary()
                {
                    Source = new Uri(
                    String.Format($"/ResiurceDictionary/dark.xaml"),
                    UriKind.Relative)
                }
            );
                chek = true;
                return;
            }
        }
        #endregion
        #region Oткрытие нового окна
        private DelegateCommand openNewWindows;

        public ICommand IOpenNewWindows
        {
            get
            {
                if (openNewWindows == null)
                {
                    openNewWindows = new DelegateCommand(OpenNewWindow);
                }
                return openNewWindows;
            }
        }
        private static void OpenNewWindow()
        {
            var newWindow = new FormToAddNewTarif();
            var newWindowViewModel = new FormToAddTarifViewModel(newWindow, thisMein._tarifsAndTeachersViewModel);
            newWindow.DataContext = newWindowViewModel;
            newWindow.ShowDialog();
        }
        //---//
        #endregion
        #region Добавить преподавателя
        private DelegateCommand addTeacher;

        public ICommand AddTeacher
        {
            get
            {
                if (addTeacher == null)
                {
                    addTeacher = new DelegateCommand(AddTeacherWindow);
                }
                return addTeacher;
            }
        }
        private static void AddTeacherWindow()
        {
            var newWindow = new FormToAddNewTeacher();
            var newWindowViewModel = new FormToAddNewTeacherViewModel(newWindow, thisMein._tarifsAndTeachersViewModel);
            newWindow.DataContext = newWindowViewModel;
            newWindow.ShowDialog();
        }
        #endregion
        #region Открытие личного кабинета

        private DelegateCommand openPersonalArea;
        public ICommand OpenPersonalArea
        {
            get
            {
                if (openPersonalArea == null)
                {
                    openPersonalArea = new DelegateCommand(OpenProfilePage);
                }
                return openPersonalArea;
            }
        }

        private void OpenProfilePage()

        {
            CurrentFrame = new Frame() { Content = new ProfilePage() { DataContext = _profileViewModel } };
        }
        #endregion
        #region Открытие главной страницы
        private DelegateCommand openMainPage;
        public ICommand OpenMainPage
        {
            get
            {
                if (openMainPage == null)
                {
                    openMainPage = new DelegateCommand(OpenMainPageM);
                }
                return openMainPage;
            }
        }

        private void OpenMainPageM()

        {
            CurrentFrame = new Frame() { Content = new MainPage() { DataContext = this } };
        }
        #endregion
        #region Открытие тарифов и преподавателей

        private DelegateCommand openTarifsArea;
        public ICommand OpenTarifsArea
        {
            get
            {
                if (openTarifsArea == null)
                {
                    openTarifsArea = new DelegateCommand(OpenTarifs);
                }
                return openTarifsArea;
            }
        }

        private void OpenTarifs()
        {
            _tarifsAndTeachersViewModel.SetUserRoles(isAdmin, isUser);
            CurrentFrame = new Frame() { Content = new TarifsAndTeachers() { DataContext = _tarifsAndTeachersViewModel } };
        }
        #endregion

        #region Открытие корзины

        private DelegateCommand openApplicationsCommand;
        public ICommand OpenApplicationsCommand
        {
            get
            {
                if (openApplicationsCommand == null)
                {
                    openApplicationsCommand = new DelegateCommand(OpenApplications);
                }
                return openApplicationsCommand;
            }
        }

        private void OpenApplications()
        {
            _applicationsViewModel.SetUserRoles(IsAdmin, IsUser);
            CurrentFrame = new Frame() { Content = new ApplicationsView() { DataContext = _applicationsViewModel } };
        }
        #endregion
        #region Show login
        private DelegateCommand? showLoginCommand;
        public ICommand ShowLoginCommand
        {
            get
            {  
                if (showLoginCommand == null)
                {
                    checkClose = false;
                    showLoginCommand = new DelegateCommand(() =>
                    { ShowWindow(new LoginView()); CloseMainView(); });
                }
                return showLoginCommand;
            }
        }
        #endregion
    }
}