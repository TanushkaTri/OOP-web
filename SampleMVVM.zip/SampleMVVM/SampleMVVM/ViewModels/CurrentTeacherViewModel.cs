﻿using SampleMVVM.Commands;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class CurrentTeacherViewModel : ViewModelBase
    {
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }
        private string description;
        public string Description
        {
            get { return description; }
            set
            {
                description = value;
                OnPropertyChanged("Description");
            }
        }
        private int experiance;
        public int Experiance
        {
            get { return experiance; }
            set
            {
                experiance = value;
                OnPropertyChanged("Experiance");
            }
        }
        private string position;
        public string Position
        {
            get { return position; }
            set
            {
                position = value;
                OnPropertyChanged("Position");
            }
        }
        private string image;
        public string Image
        {
            get { return image; }
            set
            {
                image = value;
                OnPropertyChanged("Image");
            }
        }
        public CurrentTeacher window;
        public CurrentTeacherViewModel(CurrentTeacher window, Teacher teacher)
        {
            this.window = window;
            Name = teacher.Name;
            Description = teacher.Description;
            Experiance = teacher.Experiance;
            Position = teacher.Position;
            Image = teacher.ImagePath;
        }
        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (window != null)
            {
                window.Close();
            }
        }
    }
}
