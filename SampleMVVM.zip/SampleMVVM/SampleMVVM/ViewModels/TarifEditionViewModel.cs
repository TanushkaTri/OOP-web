﻿using Microsoft.EntityFrameworkCore.Query;
using Microsoft.Win32;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Windows;
using System.Windows.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SampleMVVM.ViewModels
{
    public class TarifEditionViewModel : ViewModelBase
    {
        #region Поля
        private Tarif tarif;
        public Tarif Tarif
        {
            get { return tarif; }
            set
            {
                tarif = value;
                OnPropertyChanged("Tarif");
            }
        }
        private string name;
        public string Name
        {
            get { return name; }
            set 
            { 
                name = value;
                OnPropertyChanged("Name");
            }
        }
        private string description;
        public string Description
            {
            get { return description; }
            set
            {
                description = value;
                OnPropertyChanged("Description");
            }
        }
        private int duration;
        public int Duration
        {
            get { return duration; }
            set
            {
                duration = value;
                OnPropertyChanged("Duration");
            }
        }
        private int cost;
        public int Cost
        {
            get { return cost; }
            set
            {
                cost = value;
                OnPropertyChanged("Cost");
            }
        }
        private string image;
        public string Image
        {
            get { return image; }
            set
            {
                image = value;
                OnPropertyChanged("Image");
            }
        }
        #endregion
        private EditTarifView windows;
        public TarifEditionViewModel(Tarif newtarif, EditTarifView windows)
        {
            this.tarif = newtarif;
            Name = tarif.Name;
            Description = tarif.Title;
            Duration = tarif.Duration;
            Cost = tarif.Cost;
            Image = tarif.ImagePath;
            this.windows = windows; 
        }
        #region Команды

        private DelegateCommand loadImageCommand;
        public ICommand LoadImageCommand
        {
            get
            {
                return loadImageCommand ?? (loadImageCommand = new DelegateCommand(LoadImage));
            }
        }

        private void LoadImage()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                Image = openFileDialog.FileName;
            }
        }

        private DelegateCommand saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                return saveCommand ?? (saveCommand = new DelegateCommand(Save));
            }
        }

        private void Save()
        {
            if (Image == null)
            {
                Image = tarif.ImagePath;
            }

            if (string.IsNullOrEmpty(Name))
            {
                Name = tarif.Title;
            }

            if (string.IsNullOrEmpty(Description))
            {
                Description = tarif.Title;
            }
            if (Duration <= 0 )
            {
                Duration = tarif.Duration;
            }
            if (Cost <= 0)
            {
                Cost = tarif.Cost;
            }

            tarif.Name = Name;
            tarif.Title = Description;
            tarif.Duration = Duration;
            tarif.Cost = Cost;
            tarif.ImagePath = Image;

            StudioManager.Instance.unitOfWork.UpdateTarif(tarif);
            MessageBox.Show(Application.Current.FindResource("gut").ToString());

            CloseWindow();
        }

        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (windows != null)
            {
                windows.Close();
            }
        }

        #endregion
    }
}
