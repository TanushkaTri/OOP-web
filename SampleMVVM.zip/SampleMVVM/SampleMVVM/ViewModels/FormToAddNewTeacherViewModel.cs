﻿using Microsoft.Win32;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Windows;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class FormToAddNewTeacherViewModel : ViewModelBase
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Experiance { get; set; }
        public string Position { get; set; }
        public string Image { get; set; }
        public TarifsAndTeachersViewModel s;

        #region Errors
        private string errorName = string.Empty;
        private string errorDescription = string.Empty;
        private int errorExperiance = 0;
        private string errorPosition = string.Empty;
        public string ErrorName
        {
            get => errorName;
            set
            {
                errorName = value;
                OnPropertyChanged(nameof(ErrorName));
            }
        }

        public string ErrorDescription
        {
            get => errorDescription;
            set
            {
                errorDescription = value;
                OnPropertyChanged(nameof(ErrorDescription));
            }
        }
        public string ErrorPosition
        {
            get => errorPosition;
            set
            {
                errorPosition = value;
                OnPropertyChanged(nameof(ErrorPosition));
            }
        }
        public int ErrorExperiance
        {
            get => errorExperiance;
            set
            {
                errorExperiance = value;
                OnPropertyChanged(nameof(ErrorExperiance));
            }
        }
        #endregion

        private FormToAddNewTeacher windows;
        private DelegateCommand createItem;
        public FormToAddNewTeacherViewModel(FormToAddNewTeacher windows, TarifsAndTeachersViewModel vm)
        {
            this.windows = windows;
            s = vm;
        }
        public ICommand CreateItem
        {
            get
            {
                if (createItem == null)
                {
                    createItem = new DelegateCommand(AddTeacher);
                }
                return createItem;
            }
        }
        private void AddTeacher()
        {
            ErrorName = "";
            ErrorDescription = "";
            ErrorPosition = "";
            ErrorExperiance = 0;
            if (Image == null)
            {
                MessageBox.Show("Добавте картинку!");
                return;
            }
            else if (Name == "" || Name == null)
            {
                ErrorName = "Введите имя преподавателя.";
                return;
            }
            else if (Description == "" || Description == null)
            {
                ErrorDescription = "Введите описание";
                return;
            }
            else if (Position == "" || Position == null)
            {
                ErrorPosition = "Введите должность";
                return;
            }
            else if (Experiance == 0 || Experiance == null)
            {
                ErrorExperiance = 0;
                return;
            }

            Teacher teacher = new Teacher();
            teacher.Name = Name;
            teacher.Experiance = Experiance;
            teacher.Description = Description;
            teacher.Position = Position;
            teacher.ImagePath = Image;
            StudioManager.Instance.unitOfWork.TeacherRepositories.Create(teacher);
            StudioManager.Instance.unitOfWork.Save();
            MessageBox.Show(Application.Current.FindResource("gut").ToString());
            s.RefreshTeachers();
            CloseWindow();
        }

        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (windows != null)
            {
                windows.Close();
            }
        }
        #region Добавить изображение
        private DelegateCommand loadImageCommand;
        public ICommand LoadImageCommand
        {
            get
            {
                if (loadImageCommand == null)
                {
                    loadImageCommand = new DelegateCommand(LoadImage);
                }
                return loadImageCommand;
            }
        }

        private void LoadImage()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                Image = openFileDialog.FileName;
            }
        }
        #endregion
    }
}
