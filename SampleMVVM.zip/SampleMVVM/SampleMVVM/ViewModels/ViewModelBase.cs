﻿using Microsoft.VisualBasic.ApplicationServices;
using SampleMVVM.DataBase;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        protected ViewModelBase()
        {
            RefreshTeachers();
            RefreshTarifs();
        }
        #region Fields

        protected static ApplicationContext db = new();

        protected static Users? CurrentUser = new();
        protected static Admin? CurrentAdmin = new();

        public static MainView? MainView = new MainView();
        private static Frame? MainFrame ;

        private static bool isAdmin = false;
        private static bool isUser = false;

        private ObservableCollection<Tarif> tarifs;
        private ObservableCollection<Teacher> teachers;
        public ObservableCollection<Tarif> Tarifs
        {
            get { return tarifs; }
            set { tarifs = value; OnPropertyChanged(nameof(Tarifs)); }
        }
        public ObservableCollection<Teacher> Teachers
        {
            get { return teachers; }
            set { teachers = value; OnPropertyChanged(nameof(Teachers)); }
        }
        public void RefreshTeachers()
        {
            teachers = new ObservableCollection<Teacher>(db.GetTeacherList());
        }
        public void RefreshTarifs()
        {
            tarifs = new ObservableCollection<Tarif>(db.GetTarifsList());
        }

        public bool IsAdmin { get { return isAdmin; } set { isAdmin = value; OnPropertyChanged(nameof(IsAdmin)); } }
        public bool IsUser { get { return isUser; } set { isUser = value; OnPropertyChanged(nameof(IsUser)); } }

        #endregion
        protected static void ShowMainWindow()
        {
            MainView view = new MainView();
            MainView = view;
            MainFrame = view.MainFrame;
            view.Show();
            MainPage mainPage = new MainPage();
            MainFrame.Content = mainPage;
        }
        protected static void CloseMainView()
        {
            MainView.Close();
        }
        protected static void ShowPage(Page page)
        {
            MainFrame.Content = page;
        }
        protected void ShowWindow(Window window)
        {
            window.Show();
        }

        private ObservableCollection<ApplicationDetails> applicationDetails;
        public ObservableCollection<ApplicationDetails> ApplicationDetailss
        {
            get { return applicationDetails; }
            set { applicationDetails = value;  OnPropertyChanged(nameof(ApplicationDetails)); }
        }

        private ObservableCollection<Applications> applications;
        public ObservableCollection<Applications> Applications
        {
            get { return applications; }
            set { applications = value; OnPropertyChanged(nameof(Applications)); }
        }

        public void RefreshAllApplications()
        {
            if (IsAdmin)
            {
                Applications = new ObservableCollection<Applications>(StudioManager.Instance.unitOfWork.ApplicationRepository.GetAll());
                GetAllTarifsAndUsersForAdmin();
            }
            else
            {
                Applications = new ObservableCollection<Applications>(StudioManager.Instance.unitOfWork.ApplicationRepository.GetApplicationsByUserId(CurrentUser.Id));
                GetAllTarifsAndUsersForUser(CurrentUser.Id);
                if (Applications == null)
                {
                    Applications = new ObservableCollection<Applications>();
                }
            }
            OnPropertyChanged(nameof(Applications)); // Уведомление об изменении Applications
            OnPropertyChanged(nameof(ApplicationDetailss)); // Уведомление об изменении  ApplicationDetailss
        }

        public void GetAllTarifsAndUsersForAdmin()
        {
            ApplicationDetailss = new ObservableCollection<ApplicationDetails>();
            foreach (var application in Applications)
            {
                Tarif tarif = StudioManager.Instance.unitOfWork.TarifsRepositories.Get(application.TarifId);
                Teacher teacher = StudioManager.Instance.unitOfWork.TeacherRepositories.Get(application.TeacherId);
                int id = application.Id;
                Users user = StudioManager.Instance.unitOfWork.UsersRepositories.Get(application.UserId);
                ApplicationDetailss.Add(new ApplicationDetails { ApplicationId = id, Tarif = tarif, Teacher = teacher, UserEmail = user.Email, UserName = user.UserName });
            }
            OnPropertyChanged(nameof(ApplicationDetailss));
        }

        public void GetAllTarifsAndUsersForUser(int userId)
        {
            ApplicationDetailss = new ObservableCollection<ApplicationDetails>();
            foreach (var application in Applications)
            {
                if (userId == application.UserId)
                {
                    Tarif tarif = StudioManager.Instance.unitOfWork.TarifsRepositories.Get(application.TarifId);
                    Teacher teacher = StudioManager.Instance.unitOfWork.TeacherRepositories.Get(application.TeacherId);
                    int id = application.Id;
                    Users user = StudioManager.Instance.unitOfWork.UsersRepositories.Get(application.UserId);
                    ApplicationDetailss.Add(new ApplicationDetails { ApplicationId = id, Tarif = tarif, Teacher = teacher, UserEmail = user.Email, UserName = user.UserName });
                }
            }
            OnPropertyChanged(nameof(ApplicationDetailss));
        }

    }
}
