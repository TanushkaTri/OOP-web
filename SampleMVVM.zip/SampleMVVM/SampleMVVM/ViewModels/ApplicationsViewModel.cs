﻿using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Windows;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class ApplicationsViewModel : ViewModelBase
    {
    
        private ApplicationDetails selectedApplication;
        public ApplicationDetails SelectedApplication
        {
            get { return selectedApplication; }
            set
            {
                selectedApplication = value;
                OnPropertyChanged(nameof(SelectedApplication));
            }
        }

        public ApplicationsViewModel()
        {
            RefreshAllApplications();
           
        }
        private ApplicationDetails GetSelectedApplication()
        {
            return SelectedApplication;
        }

        private DelegateCommand deleteAppclicationCommand;
        public ICommand DeleteAppclicationCommand
        {
            get
            {
                if (deleteAppclicationCommand == null)
                {
                    deleteAppclicationCommand = new DelegateCommand(DeleteApplication);
                }
                return deleteAppclicationCommand;
            }
        }
        private void DeleteApplication()
        {
            var selectedApp = GetSelectedApplication();
            if (selectedApp != null)
            {
                StudioManager.Instance.unitOfWork.ApplicationRepository.Delete(selectedApp.ApplicationId);
                ApplicationDetailss.Remove(selectedApp);
                RefreshAllApplications();
            }
        }

        private DelegateCommand sendEmailCommand;
        public ICommand SendEmailCommand
        {
            get
            {
                if (sendEmailCommand == null)
                {
                    sendEmailCommand = new DelegateCommand(SendEmail);
                }
                return sendEmailCommand;
            }
        }

        private void SendEmail()
        {
            try
            {
                SmtpClient client = new SmtpClient("smtp.mail.ru", 587);
                client.EnableSsl = true;
                client.Timeout = 20000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential("trikoza_tatjana@mail.ru", "17DtZq8DCuun0FzidzV9"); 

                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress("trikoza_tatjana@mail.ru"); 
                mailMessage.To.Add(SelectedApplication.UserEmail); // Получатель
                mailMessage.Subject = "Студия Вокала 'Chocolate voice' ";
                var selectedApplication = GetSelectedApplication();

                string messageBody = "Ваша заявка успешно рассмотрена!\nBы записаны на:\n";
                messageBody += $"Тариф: {selectedApplication.Tarif.Name}\n";
                messageBody += $"Преподаватель: {selectedApplication.Teacher.Name}\n";
                messageBody += "Расписание необходимо согласовать с преподавателем \nпо номеру +375333621522 ";


                mailMessage.Body = messageBody;


             
                client.Send(mailMessage);
                MessageBox.Show("Вы зарегистрировали заявку, после \n успешного отправления клиенту придет уведомление на почту");
                DeleteApplication();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при отправке письма: {ex.Message}");
            }
        }

        private bool isAdmin;
        private bool isUser;
        public bool CheckAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; OnPropertyChanged(nameof(CheckAdmin)); }
        }
        public bool CheckUser
        {
            get { return isUser; }
            set { isUser = value; OnPropertyChanged(nameof(CheckUser)); }
        }
        public void SetUserRoles(bool admin, bool user)
        {
            isAdmin = admin;
            isUser = user;
        }
    }

    public class ApplicationDetails : ViewModelBase
    {
        public int ApplicationId;
        public Tarif Tarif { get; set; }
        public Teacher Teacher { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }

    }
}
