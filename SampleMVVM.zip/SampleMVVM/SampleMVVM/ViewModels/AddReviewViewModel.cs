﻿using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class AddReviewViewModel : ViewModelBase
    {
        public Review Review { get; set; }
        private string name;
        public string Name
        { 
            get { return name; }
            set { name = value;
                OnPropertyChanged("Name");
            }
        }
        private string text;
        public string Text
        {
            get { return text; }
            set
            {
                text = value;
                OnPropertyChanged("Name");
            }
        }
        public AddReview window;
        private int ID;
        public AddReviewViewModel(AddReview window, int tarifId)
        {
            this.window = window;
            Review = new Review();
            ID = tarifId;
        }

        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (window != null)
            {
                window.Close();
            }
        }

        private DelegateCommand saveReviewCommand;
        public ICommand SaveReviewCommand
        {
            get
            {
                if (saveReviewCommand == null)
                {
                    saveReviewCommand = new DelegateCommand(SaveReview);
                }
                return saveReviewCommand;
            }
        }
        private void SaveReview()
        {
            if(Name == null || Name == "")
            {
                MessageBox.Show("Некорректное имя");
                Name = "";
                return;
            }
            if (Text == null || Text == "")
            {
                MessageBox.Show("Введите отзыв!");
                Name = "";
                return;
            }
            Review.Text = Text;
            Review.Name = Name;
            Review.TarifId = ID;
            StudioManager.Instance.unitOfWork.ReviewRepository.Create(Review);
            MessageBox.Show("Отзыв оставлен!");
            CloseWindow();
        }



    }
}
