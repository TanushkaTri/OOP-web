﻿using Microsoft.Win32;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    class TeacherEditionViewModel : ViewModelBase
    {
        private Teacher thisTeacher;
        private TeacherEditionView windows;
        public TeacherEditionViewModel(TeacherEditionView windows, Teacher teacher)
        {
            this.windows = windows;
            thisTeacher = teacher;
            Name = thisTeacher.Name;
            Description = thisTeacher.Description;
            Position = thisTeacher.Position;
            ImagePath = thisTeacher.ImagePath;
            Experiance = thisTeacher.Experiance;
        }
        #region Error
        private string errorName = string.Empty;
        private string errorDescription = string.Empty;
        private string errorPosition = string.Empty;
        private int errorExperiance = 0;
        public string ErrorName
        {
            get => errorName;
            set
            {
                errorName = value;
                OnPropertyChanged(nameof(ErrorName));
            }
        }

        public string ErrorDescription
        {
            get => errorDescription;
            set
            {
                errorDescription = value;
                OnPropertyChanged(nameof(ErrorDescription));
            }
        }
        public string ErrorPosition
        {
            get => errorPosition;
            set
            {
                errorPosition = value;
                OnPropertyChanged(nameof(ErrorPosition));
            }
        }
        public int ErrorExperianece
        {
            get => errorExperiance;
            set
            {
                errorExperiance = value;
                OnPropertyChanged(nameof(ErrorExperianece));
            }
        }
        #endregion
        #region Поля
        private string name;
        private string description;
        private int experiance;
        private string position;
        private string imagePath;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }
        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
                OnPropertyChanged("Description");
            }
        }
        public string Position
        {
            get
            {
                return position;
            }
            set
            {
                position = value;
                OnPropertyChanged("Position");
            }
        }
        public int Experiance
        {
            get
            {
                return experiance;
            }
            set
            {
                experiance = value;
                OnPropertyChanged("Experiance");
            }
        }
        public string ImagePath
        {
            get { return imagePath; }
            set
            {
                imagePath = value;
                OnPropertyChanged("ImagePath");
            }
        }

        #endregion
        #region Закрыть окно
        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (windows != null)
            {
                windows.Close();
            }
        }
        #endregion
        #region Добавить изображение
        private DelegateCommand loadImageCommand;
        public ICommand LoadImageCommand
        {
            get
            {
                if (loadImageCommand == null)
                {
                    loadImageCommand = new DelegateCommand(LoadImage);
                }
                return loadImageCommand;
            }
        }

        private void LoadImage()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                ImagePath = openFileDialog.FileName;
            }
        }
        #endregion
        #region сохранить изменения
        private DelegateCommand saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                if (saveCommand == null)
                {
                    saveCommand = new DelegateCommand(Save);
                }
                return saveCommand;
            }
        }
        private void Save()
        {
            ErrorName = "";
            ErrorDescription = "";
            ErrorExperianece = 0;
            ErrorPosition = "";
            if (ImagePath == null)
            {
                MessageBox.Show(Application.Current.FindResource("ErrorImage").ToString());
                return;
            }
            else if (Name == "" || Name == null)
            {
                ErrorName = Application.Current.FindResource("ErrorTeacherName").ToString();
                return;
            }
            else if (Description == "" || Description == null)
            {
                ErrorDescription = Application.Current.FindResource("ErrorTeacherDesc").ToString();
                return;
            }
            else if (Position == "" || Position == null)
            {
                ErrorPosition = Application.Current.FindResource("ErrorTeacherPosition").ToString();
                return;
            }
            else if (Experiance <=0)
            {
                ErrorExperianece = 0;
                return;
            }
            thisTeacher.Experiance = Experiance;
            thisTeacher.Position = Position;
            thisTeacher.Name = Name;
            thisTeacher.Description = Description;
            thisTeacher.ImagePath = ImagePath;
            StudioManager.Instance.unitOfWork.TeacherRepositories.Update(thisTeacher);
            MessageBox.Show(Application.Current.FindResource("gut").ToString());
            CloseWindow();
        }
        #endregion
    }
}
