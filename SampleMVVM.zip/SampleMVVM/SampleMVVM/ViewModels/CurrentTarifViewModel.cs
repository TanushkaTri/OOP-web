﻿using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    public class CurrentTarifViewModel : ViewModelBase
    {
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }
        private string description;
        public string Description
        {
            get { return description; }
            set
            {
                description = value;
                OnPropertyChanged("Description");
            }
        }
        private int duration;
        public int Duration
        {
            get { return duration; }
            set
            {
                duration = value;
                OnPropertyChanged("Duration");
            }
        }
        private int cost;
        public int Cost
        {
            get { return cost; }
            set
            {
                cost = value;
                OnPropertyChanged("Cost");
            }
        }
        private string image;
        public string Image
        {
            get { return image; }
            set
            {
                image = value;
                OnPropertyChanged("Image");
            }
        }
        public CurrentTarifView window;
        public AddReview addWindow;
        public int ID { get; set; }
        public CurrentTarifViewModel(CurrentTarifView window, Tarif tarif)
        {
            this.window = window;
            Name = tarif.Name;
            Description = tarif.Title;
            Cost = tarif.Cost;
            Duration = tarif.Duration;
            Image = tarif.ImagePath;
            ID = tarif.Id;
            Reviews = new ObservableCollection<Review>();
            UpdateReviews();
        }
        private DelegateCommand closeWindows;
        public ICommand CloseWindows
        {
            get
            {
                if (closeWindows == null)
                {
                    closeWindows = new DelegateCommand(CloseWindow);
                }
                return closeWindows;
            }
        }
        private void CloseWindow()
        {
            if (window != null)
            {
                window.Close();
            }
        }

        private ObservableCollection<Review> reviews;
        public ObservableCollection<Review> Reviews
        {
            get => reviews;
            set
            {
                reviews = value;
                OnPropertyChanged("Reviews");
            }
        }

        private void UpdateReviews()
        {
            var newReviews = StudioManager.Instance.unitOfWork.ReviewRepository.GetAll();

            if (newReviews != null)
            {
                var newReviewsCollection = new ObservableCollection<Review>(newReviews);

                foreach (var review in newReviewsCollection)
                {
                    if (!Reviews.Any(r => r.Id == review.Id))
                    {
                        if (review.TarifId == ID)
                        {
                            Reviews.Add(review);
                        }
                    }
                }
            }
        }


        private DelegateCommand addReviewCommand;
        public ICommand AddReviewCommand
        {
            get
            {
                if (addReviewCommand == null)
                {
                    addReviewCommand = new DelegateCommand(AddReview);
                }
                return addReviewCommand;
            }
        }

        private void AddReview()
        {
            addWindow = new AddReview();
            AddReviewViewModel model = new AddReviewViewModel(addWindow, ID);
            addWindow.DataContext = model;
            addWindow.ShowDialog();
            UpdateReviews();
        }




    }
}
