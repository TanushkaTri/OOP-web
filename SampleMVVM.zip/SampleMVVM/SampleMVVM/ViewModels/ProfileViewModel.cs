﻿using Microsoft.Win32;
using SampleMVVM.Commands;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using SampleMVVM.Views;
using System.Collections.Generic;
using System.Windows.Input;

namespace SampleMVVM.ViewModels
{
    class ProfileViewModel : ViewModelBase
    {
        private Users user;
        public ProfileViewModel()
        {
            user = CurrentUser;
        }
        public string Surname
        {
            get { return user.Surname; }
            set
            {
                user.Surname = value;
                OnPropertyChanged(nameof(Surname));
            }
        }

        public string Name
        {
            get => user.FirstName;
            set
            {
                user.FirstName = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        public string LastName
        {
            get => user.LastName;
            set
            {
                user.LastName = value;
                OnPropertyChanged(nameof(LastName));
            }
        }

        public string Login
        {
            get => user.UserName;
            set
            {
                user.UserName = value;
                OnPropertyChanged(nameof(Login));
            }
        }
        public string Email
        {
            get => user.Email;
            set
            {
                user.Email = value;
                OnPropertyChanged(nameof(Email));
            }
        }
        public string PhotoPath
        {
            get => user.PhotoPath;
            set
            {
                user.PhotoPath = value;
                OnPropertyChanged(nameof(PhotoPath));
            }
        }
        #region Сохранить персональные данные
        private DelegateCommand savePersonalInfoCommand;
        public ICommand SavePersonalInfoCommand
        {
            get
            {
                if (savePersonalInfoCommand == null)
                {
                    savePersonalInfoCommand = new DelegateCommand(SavePersonalInfo);
                }
                return savePersonalInfoCommand;
            }
        }

        private void SavePersonalInfo()
        {
            StudioManager.Instance.unitOfWork.UsersRepositories.UpdatePersonalInfo(user);
        }
        #endregion

        #region Сохранить данные для авторизации
        private DelegateCommand saveLoginInfoCommand;
        public ICommand SaveLoginInfoCommand
        {
            get
            {
                if (saveLoginInfoCommand == null)
                {
                    saveLoginInfoCommand = new DelegateCommand(SaveLoginInfo);
                }
                return saveLoginInfoCommand;
            }
        }

        private void SaveLoginInfo()
        {
            StudioManager.Instance.unitOfWork.UsersRepositories.UpdateLoginInfo(user);
        }
        #endregion

        #region Сохранить данные для авторизации
        private DelegateCommand choosePhoto;
        public ICommand ChoosePhoto
        {
            get
            {
                if (choosePhoto == null)
                {
                    choosePhoto = new DelegateCommand(SearchNewPhoto);
                }
                return choosePhoto;
            }
        }

        private void SearchNewPhoto()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.gif)|*.jpg; *.jpeg; *.png; *.gif";
            if (openFileDialog.ShowDialog() == true)
            {
                string selectedImagePath = openFileDialog.FileName;
                user.PhotoPath = selectedImagePath;
                StudioManager.Instance.unitOfWork.UsersRepositories.UpdateUserPhoto(CurrentUser.Id, user.PhotoPath);
                OnPropertyChanged(nameof(PhotoPath));
            }
        }
        #endregion

    }
}
