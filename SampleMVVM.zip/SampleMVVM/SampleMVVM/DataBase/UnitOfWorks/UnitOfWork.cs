﻿
using SampleMVVM.DataBase.Repositories;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.DataBase.UnitOfWorks
{
    public class UnitOfWork : IDisposable
    {
        private ApplicationContext db = new ApplicationContext();
        private AdminRepository adminRepository;
        private TarifsRepositories tarifsRepositories;
        private UsersRepositories usersRepositories;
        private TeacherRepositories teacherRepositories;
        private ApplicationRepository applicationRepository;
        private ReviewRepository reviewRepository;
        public ApplicationRepository ApplicationRepository
        {
            get
            {
                if (applicationRepository == null)
                    applicationRepository = new ApplicationRepository(db);
                return applicationRepository;
            }
        }
        public ReviewRepository ReviewRepository
        {
            get
            {
                if (reviewRepository == null)
                    reviewRepository = new ReviewRepository(db);
                return reviewRepository;
            }
        }
        public TeacherRepositories TeacherRepositories
        {
            get
            {
                if (teacherRepositories == null)
                    teacherRepositories = new TeacherRepositories(db);
                return teacherRepositories;
            }
        }

        public AdminRepository AdminRepository
        {
            get
            {
                if (adminRepository == null)
                    adminRepository = new AdminRepository(db);
                return adminRepository;
            }
        }
        public TarifsRepositories TarifsRepositories
      {
            get
            {
                if (tarifsRepositories == null)
                tarifsRepositories = new TarifsRepositories(db);
                return tarifsRepositories;
            }
        }
        public UsersRepositories UsersRepositories
        {
            get
            {
                if (usersRepositories == null)
                    usersRepositories = new UsersRepositories(db);
                return usersRepositories;
            }
        }
        public void UpdateTarif(Tarif tarif)
        {
            var tarifRepository = TarifsRepositories;

            var existingTarif = tarifRepository.Get(tarif.Id);
            if (existingTarif == null)
            {
                throw new ArgumentException($"Tarif with ID {tarif.Id} not found.");
            }

            existingTarif.Name = tarif.Name;
            existingTarif.Title = tarif.Title;
            existingTarif.Duration = tarif.Duration;
            existingTarif.Cost = tarif.Cost;
            existingTarif.ImagePath = tarif.ImagePath;

            Save();
        }
        public void Save()
        {
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }

}
