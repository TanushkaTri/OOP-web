﻿using Microsoft.EntityFrameworkCore;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.DataBase.Repositories
{
    public class ApplicationRepository : IRepository<Applications>
    {
        private ApplicationContext db;

        public ApplicationRepository(ApplicationContext context)
        {
            db = context;
        }

        public IEnumerable<Applications> GetAll()
        {
            return db.Applications
                .ToList();
        }
        public IQueryable<Applications> GetApplicationsByUserId(int userId)
        {
            return db.Applications
                .Where(app => app.UserId == userId);
        }

        public Applications Get(int id)
        {
            return db.Applications
                .Include(app => app.UserId)
                .Include(app => app.TarifId)
                .Include(app => app.TeacherId)
                .FirstOrDefault(app => app.Id == id);
        }

        public void Create(Applications application)
        {
            db.Applications.Add(application);
            db.SaveChanges();
        }

        public void Update(Applications application)
        {
            db.Entry(application).State = EntityState.Modified;
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            var application = db.Applications.Find(id);
            if (application != null)
            {
                db.Applications.Remove(application);
                db.SaveChanges();
            }
        }
    }
}
