﻿using Microsoft.EntityFrameworkCore;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleMVVM.DataBase.Repositories
{
    public class TarifsRepositories : IRepository<Tarif>
    {
        private ApplicationContext db;

        public TarifsRepositories(ApplicationContext context)
        {
            this.db = context;
        }

        public IEnumerable<Tarif> GetAll()
        {
            return db.Tarifs;
        }

        public Tarif Get(int id)
        {
            return db.Tarifs.Find(id);
        }

        public void Create(Tarif tarif)
        {
            db.Tarifs.Add(tarif);
            db.SaveChanges();
        }

        public void Update(Tarif tarif)
        {
            db.Entry(tarif).State = EntityState.Modified;
            db.SaveChanges();
        }
        public void Delete(int id)
        {
            Tarif tarif = db.Tarifs.Find(id);

            if (tarif == null)
                return;

            db.Tarifs.Remove(tarif);
            db.SaveChanges();
        }
        public void DeleteByName(Tarif tarif)
        {

            if (tarif == null)
                return;

            db.Tarifs.Remove(tarif);
            db.SaveChanges();
        }


        public List<Tarif> Search(string searchString)
        {
            return db.Tarifs
                .Where(x => x.Name.ToLower().Contains(searchString.ToLower()))
                .ToList();
        }
    }
}
