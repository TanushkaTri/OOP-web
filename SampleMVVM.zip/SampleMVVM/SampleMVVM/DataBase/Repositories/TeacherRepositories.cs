﻿using Microsoft.EntityFrameworkCore;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleMVVM.DataBase.Repositories
{
    public class TeacherRepositories : IRepository<Teacher>, IDisposable
    {
        private ApplicationContext db;

        public TeacherRepositories(ApplicationContext context)
        {
            this.db = context;
        }

        public IEnumerable<Teacher> GetAll()
        {
            return db.Teachers.ToList();
        }

        public Teacher Get(int id)
        {
            return db.Teachers.Find(id);
        }

        public void Create(Teacher teacher)
        {
            db.Teachers.Add(teacher);
            db.SaveChanges();
        }

        public void Update(Teacher teacher)
        {
            db.Entry(teacher).State = EntityState.Modified;
            db.SaveChanges();
        }

        public void Delete(int id)
        {
            Teacher teacher = db.Teachers.Find(id);

            if (teacher == null)
                return;

            db.Teachers.Remove(teacher);
            db.SaveChanges();
        }
        public void DeleteByName(Teacher teacher)
        {
            if (teacher == null)
                return;

            db.Teachers.Remove(teacher);
            db.SaveChanges();
        }

        public List<Teacher> Search(string searchString)
        {
            return db.Teachers
                .Where(x => x.Name.ToLower().Contains(searchString.ToLower()))
                .ToList();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}
