﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SampleMVVM.DataBase.UnitOfWorks;
using SampleMVVM.Managers;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.DataBase.Repositories
{
    public class UsersRepositories : IRepository<Users>
    {
        private ApplicationContext db;
        public UsersRepositories(ApplicationContext context)
        {
            this.db = context;
        }
        public IEnumerable<Users> GetAll()
        {
            return db.Users;
        }
        public Users Get(int id)
        {
            return db.Users.Find(id);
        }
        public void Create(Users user)
        {
            UserList userList = new UserList();
            userList.User = user;
            userList.List_Name = "";
            db.Users.Add(user);
            StudioManager.Instance.unitOfWork.Save();
        }
        public void Update(Users userList)
        {
            db.Entry(userList).State = EntityState.Modified;
        }

        public void Delete(int id)
        {
            Users userList = db.Users.Find(id);
            if (userList != null)
                db.Users.Remove(userList);
        }
        public bool AuthenticateUser(NetworkCredential credential)
        {
            bool validUser;
            return true;
        }
        public void SaveChanges()
        {
            StudioManager.Instance.unitOfWork.Save();
        }

        public void UpdateUserData(Users user)
        {
            Update(user);

            SaveChanges();
        }
        public void UpdateLoginInfo(Users user)
        {
            var existingUser = StudioManager.Instance.unitOfWork.UsersRepositories.Get(user.Id);
            if (existingUser != null)
            {
                existingUser.UserName = user.UserName;
                existingUser.Email = user.Email;
                StudioManager.Instance.unitOfWork.UsersRepositories.Update(existingUser);
                StudioManager.Instance.unitOfWork.Save();
            }
        }

        public void UpdatePersonalInfo(Users user)
        {
            var existingUser = StudioManager.Instance.unitOfWork.UsersRepositories.Get(user.Id);
            if (existingUser != null)
            {
                existingUser.FirstName = user.FirstName;
                existingUser.LastName = user.LastName;
                existingUser.Surname = user.Surname;
                StudioManager.Instance.unitOfWork.UsersRepositories.Update(existingUser);
                StudioManager.Instance.unitOfWork.Save();
            }
        }
        public void UpdateUserPhoto(int userId, string photoPath)
        {
            var existingUser = db.Users.Find(userId);
            if (existingUser != null)
            {
                existingUser.PhotoPath = photoPath;
                db.SaveChanges();
            }
        }


    }
}
