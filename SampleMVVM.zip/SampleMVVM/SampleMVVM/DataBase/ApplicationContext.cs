﻿using Microsoft.EntityFrameworkCore;
using SampleMVVM.Model.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleMVVM.DataBase
{
    public class ApplicationContext : DbContext
    {
        public DbSet<Users> Users { get; set; } = null!;
        public DbSet<Admin> Admin { get; set; } = null!;
        public DbSet<UserList> UserList { get; set; } = null!;
        public DbSet<Teacher> Teachers { get; set; } = null!;
        public DbSet<Tarif> Tarifs { get; set; } = null!;
        public DbSet<Applications> Applications { get; set; } = null!;
        public DbSet<Review> Reviews { get; set; } = null!;
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=LAPTOP-0UR880TP;Database=MyStudio;Trusted_Connection=True;TrustServerCertificate=True;");
        }
        public List<Users> GetUserList()
        {
            using var context = new ApplicationContext();
            return context.Users.ToList();
        }
        public List<Review> GetReviewsList()
        {
            using var context = new ApplicationContext();
            return context.Reviews.ToList();
        }
        public List<Teacher> GetTeacherList()
        {
            using var context = new ApplicationContext();
            return context.Teachers.ToList();
        }
        public List<Applications> GetAllApplications()
        {
            using var context = new ApplicationContext();
            return context.Applications.ToList();
        }
        public List<Tarif> GetTarifsList()
        {
            using var context = new ApplicationContext();
            return context.Tarifs.ToList();
        }
        public List<Admin> GetAdminList()
        {
            using var context = new ApplicationContext();
            return context.Admin.ToList();
        }
    }
}
